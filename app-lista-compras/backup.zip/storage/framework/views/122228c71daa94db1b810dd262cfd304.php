<?php $__env->startSection('title', "Editar a Dúvida {$support->subject}"); ?>

<?php $__env->startSection('header'); ?>
    <h1 class="text-lg text-black-500">Dúvida <?php echo e($support->subject); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('supports.update', $support->id)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('admin.supports.partials.form', [
            'support' => $support
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/supports/edit.blade.php ENDPATH**/ ?>