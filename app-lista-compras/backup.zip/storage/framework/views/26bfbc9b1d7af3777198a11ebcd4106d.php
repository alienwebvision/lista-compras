<?php $__env->startSection('title', 'Criar Novo Tópico'); ?>

<?php $__env->startSection('header'); ?>
<h1 class="text-lg text-black-500">Nova Dúvida</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('supports.store')); ?>" method="POST">
    <?php echo $__env->make('admin.supports.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/supports/create.blade.php ENDPATH**/ ?>