<!-- Smile, breathe, and go slowly. - Thich Nhat Hanh -->

    <form action="<?php echo e(route('supports.destroy', $support->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-danger" type="submit">Deletar</button>
    </form>
<?php /**PATH /var/www/html/resources/views/components/delete.blade.php ENDPATH**/ ?>