<?php $__env->startSection('title', "Detalhes da Dúvida {$support->subject}"); ?>

<?php $__env->startSection('header'); ?>
    <h1 class="text-lg text-black-500">Dúvida <?php echo e($support->subject); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <ul>
        <li>Assunto: <?php echo e($support->subject); ?></li>
        <li>Status: <?php echo e($support->status); ?></li>
        <li>Descrição: <?php echo e($support->body); ?></li>
    </ul>

    <form action="<?php echo e(route('supports.destroy', $support->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit"
                class="bg-red-500 hover:bg-red-400 text-white font-bold py-2 px-4 border-b-4 border-red-700 hover:border-red-500 rounded">
            Deletar
        </button>
        <button type="submit"
                class="bg-blue-500 hover:bg-blue-400 text-white font-bold py-2 px-4 border-b-4 border-blue-700 hover:border-blue-500 rounded">
            <a href="<?php echo e(route('supports.index')); ?>">Voltar</a></button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/supports/show.blade.php ENDPATH**/ ?>