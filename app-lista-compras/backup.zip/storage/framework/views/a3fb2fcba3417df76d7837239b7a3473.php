<div class="inline px-3 py-1 text-sm font-normal rounded-full text-<?php echo e($color); ?>-500 gap-x-2 bg-<?php echo e($color); ?>-100/60">
    <?php echo e($textStatus); ?>

</div>
<?php /**PATH /var/www/html/resources/views/components/status-support.blade.php ENDPATH**/ ?>